package org.retroclubkit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetroClubKitApplicationTests {

    @Test
    void contextLoads() {
    }

}
