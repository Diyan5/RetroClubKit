package org.retroclubkit.payment.model;

public enum PaymentMethod {

    CREDIT_CARD, PAYPAL, CASH_ON_DELIVERY;
}
