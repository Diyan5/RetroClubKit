package org.retroclubkit.tshirt.model;

public enum Size {
    XS, S, M, L, XL
}
