package org.retroclubkit.tshirt.model;

public enum Category {
    NATIONAL, RETRO, NEW
}
