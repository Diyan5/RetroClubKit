package org.retroclubkit.user.model;

public enum UserRole {
    ADMIN, USER
}
