package org.retroclubkit.order.model;

public enum Status {
    PENDING, COMPLETED
}
