package org.retroclubkit;

import org.retroclubkit.web.dto.LoginRequest;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class CommandRunner implements CommandLineRunner {
    @Override
    public void run(String... args) throws Exception {
//        LoginRequest loginRequest = new LoginRequest();
//        loginRequest.setUsername("admin");
//        loginRequest.setPassword("admin");
//        String a = loginRequest.getUsername();
//        System.out.println();
    }
}
